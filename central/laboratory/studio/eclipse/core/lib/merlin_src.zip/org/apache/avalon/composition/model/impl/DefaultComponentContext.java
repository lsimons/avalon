/* 
 * Copyright 2004 Apache Software Foundation
 * Licensed  under the  Apache License,  Version 2.0  (the "License");
 * you may not use  this file  except in  compliance with the License.
 * You may obtain a copy of the License at 
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.avalon.composition.model.impl;

import java.io.File;
import java.util.Map;
import java.util.Hashtable;

import org.apache.avalon.composition.data.ComponentProfile;
import org.apache.avalon.composition.model.ContainmentModel;
import org.apache.avalon.composition.model.DeploymentModel;
import org.apache.avalon.composition.model.EntryModel;
import org.apache.avalon.composition.model.ModelRuntimeException;
import org.apache.avalon.composition.model.DependencyGraph;
import org.apache.avalon.composition.provider.SystemContext;
import org.apache.avalon.composition.provider.ContainmentContext;
import org.apache.avalon.composition.provider.ComponentContext;

import org.apache.avalon.framework.context.ContextException;
import org.apache.avalon.framework.context.DefaultContext;
import org.apache.avalon.framework.logger.Logger;

import org.apache.avalon.excalibur.i18n.ResourceManager;
import org.apache.avalon.excalibur.i18n.Resources;

import org.apache.avalon.meta.info.Type;
import org.apache.avalon.meta.info.EntryDescriptor;
import org.apache.avalon.meta.info.DependencyDescriptor;
import org.apache.avalon.meta.info.StageDescriptor;


/**
 * Default implementation of a deployment context that is used
 * as the primary constructor argument when creating a new component
 * model.
 *
 * @author <a href="mailto:dev@avalon.apache.org">Avalon Development Team</a>
 * @version $Revision: 1.6 $ $Date: 2004/02/10 16:23:33 $
 */
public class DefaultComponentContext extends DefaultDeploymentContext 
  implements ComponentContext
{
    //==============================================================
    // static
    //==============================================================

    private static final Resources REZ =
            ResourceManager.getPackageResources( DefaultComponentContext.class );

    //==============================================================
    // immutable state
    //==============================================================

    private final ClassLoader m_classloader;

    private final ComponentProfile m_profile;

    private final Type m_type;

    private final Class m_class;

    private final File m_home;

    private final File m_temp;

    private final ContainmentModel m_model;

   /**
    * Map containing context entry models 
    * keyed by entry key.
    */
    private final Map m_map = new Hashtable();

    //==============================================================
    // constructor
    //==============================================================

   /**
    * Creation of a new deployment context.
    *
    * @param logger the logging channel to assign
    * @param name the deployment context name
    * @param system the system context
    * @param classloader the containers classloader
    * @param graph the containers dependency graph
    * @param profile the deployment profile
    * @param type the underlying component type
    * @param clazz the compoent deployment class
    * @param home the home working directory
    * @param temp a temporary directory 
    * @param partition the partition name 
    */
    public DefaultComponentContext( 
      Logger logger, String name, SystemContext system, ClassLoader classloader, 
      DependencyGraph graph, ContainmentModel model, ComponentProfile profile, 
      Type type, Class clazz, File home, File temp, String partition )
    {
        super( 
          logger, system, partition, name, profile.getMode(), graph );

        if( partition == null )
        {
            throw new NullPointerException( "partition" );
        }
        if( classloader == null )
        {
            throw new NullPointerException( "classloader" );
        }
        if( clazz == null )
        {
            throw new NullPointerException( "clazz" );
        }
        if( type == null )
        {
            throw new NullPointerException( "type" );
        }
        if( profile == null )
        {
            throw new NullPointerException( "profile" );
        }
        if( model == null )
        {
            throw new NullPointerException( "model" );
        }

        if( home.exists() && !home.isDirectory() )
        {
            final String error = 
              REZ.getString( "deployment.context.home.not-a-directory.error", home  );
            throw new IllegalArgumentException( error );
        }
        if( temp.exists() && !temp.isDirectory() )
        {
            final String error = 
              REZ.getString( "deployment.context.temp.not-a-directory.error", temp  );
            throw new IllegalArgumentException( error );
        }

        m_home = home;
        m_temp = temp;
        m_classloader = classloader;
        m_type = type;
        m_profile = profile;
        m_class = clazz;
        m_model = model;
    }

    //==============================================================
    // ContainmentContext
    //==============================================================

   /**
    * Return the enclosing containment model.
    * @return the containment model that component is within
    */
    public ContainmentModel getContainmentModel() 
    {
        return m_model;
    }

   /**
    * Return the working directory.
    *
    * @return the working directory
    */
    public File getHomeDirectory()
    {
        return m_home;
    }

   /**
    * Return the temporary directory.
    *
    * @return the temporary directory
    */
    public File getTempDirectory()
    {
        return m_temp;
    }

   /**
    * Return the deployment profile.
    *
    * @return the profile
    */
    public ComponentProfile getProfile()
    {
        return m_profile;
    }

   /**
    * Return the component type.
    *
    * @return the type defintion
    */
    public Type getType()
    {
        return m_type;
    }

   /**
    * Return the component class.
    *
    * @return the class
    */
    public Class getDeploymentClass()
    {
        return m_class;
    }

   /**
    * Return the classloader for the component.
    *
    * @return the classloader
    */
    public ClassLoader getClassLoader()
    {
        return m_classloader;
    }

   /**
    * Add a context entry model to the deployment context.
    * @param model the entry model
    * @exception IllegalArgumentException if model key is unknown
    */
    public void register( EntryModel model )
    {
        final String key = model.getKey();
        if( m_map.get( key ) == null )
        {
            m_map.put( key, model );
        }
        else
        {
            final String error = 
              REZ.getString( "deployment.registration.override.error", key );
            throw new IllegalArgumentException( error );
        }
    }

   /**
    * Get a context entry from the deployment context.
    * @param alias the entry lookup key
    * @return value the corresponding value
    * @exception ContextException if the key is unknown
    * @exception ModelRuntimeException if the key is unknown
    */
    public Object resolve( final String alias ) throws ContextException
    {
        if( alias == null ) throw new NullPointerException( "alias" );

        String key = alias;
        EntryDescriptor entry = 
          getType().getContext().getEntry( alias );

        if( entry != null )
        {
            key = entry.getKey();
        }
        
        if( key.equals( ContainmentModel.KEY ) )
        {
            return getContainmentModel();
        }
        else if( key.startsWith( "urn:composition:" ) )
        {
            return getSystemContext().get( key );
        }
        else if( key.equals( NAME_KEY ) )
        {
            return getName();
        }
        else if( key.equals( PARTITION_KEY ) )
        {
            return getPartitionName();
        }
        else if( key.equals( CLASSLOADER_KEY ) )
        {
            return getClassLoader();
        }
        else if( key.equals( HOME_KEY ) )
        {
            return getHomeDirectory();
        }
        else if( key.equals( TEMP_KEY ) )
        {
            return getTempDirectory();
        }
        else
        {
            Object object = m_map.get( key );
            if( null != object )
            {
                final String classname = object.getClass().getName();
                try
                {
                    return ((EntryModel)object).getValue();
                }
                catch( Throwable e )
                {
                    final String error = 
                      REZ.getString( 
                        "deployment.context.runtime-get", 
                        key, classname );
                    throw new ModelRuntimeException( error, e );
                }
            }
            else
            {
                final String error = 
                  REZ.getString( 
                   "deployment.context.runtime-get", key );
                throw new ModelRuntimeException( error );
            }
        }
    }
}
