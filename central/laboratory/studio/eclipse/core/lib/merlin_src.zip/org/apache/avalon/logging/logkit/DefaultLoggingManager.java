/* 
 * Copyright 2004 Apache Software Foundation
 * Licensed  under the  Apache License,  Version 2.0  (the "License");
 * you may not use  this file  except in  compliance with the License.
 * You may obtain a copy of the License at 
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.avalon.logging.logkit;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

import org.apache.avalon.logging.provider.LoggingManager;
import org.apache.avalon.logging.provider.LoggingException;

import org.apache.avalon.excalibur.i18n.ResourceManager;
import org.apache.avalon.excalibur.i18n.Resources;

import org.apache.avalon.framework.logger.Logger;
import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.logging.data.CategoryDirective;
import org.apache.avalon.logging.data.CategoriesDirective;

import org.apache.log.Hierarchy;
import org.apache.log.LogTarget;
import org.apache.log.Priority;
import org.apache.log.output.io.FileTarget;
import org.apache.log.output.io.StreamTarget;

/**
 * A <code>LoggerManager</code> interface declares operation supporting
 * the management of a logging hierarchy.
 *
 * @author <a href="mailto:dev@avalon.apache.org">Avalon Development Team</a>
 */
public class DefaultLoggingManager implements LoggingManager
{
    //---------------------------------------------------------------
    // static
    //---------------------------------------------------------------

    private static final Resources REZ =
      ResourceManager.getPackageResources( DefaultLoggingManager.class );

    private static final String DEFAULT_PRIORITY = "INFO";

    private static final String DEFAULT_TARGET = "default";

    //---------------------------------------------------------------
    // immutable state
    //---------------------------------------------------------------

    /**
     * The list of named logging targets.
     */
    private final LogTargetManager m_targets;

    /**
     * The implementation log hierarchy.
     */
    private final Hierarchy m_hierarchy = new Hierarchy();

    /**
     * The bootstrap logging channel.
     */
    private final Logger m_logger;

    /**
     * Debug mode flag.
     */
    private final boolean m_debug;

    //--------------------------------------------------------------
    // constructor
    //--------------------------------------------------------------

    /**
     * Creation of a new logging manager using based on LogKit.
     *
     * @param logger boostrap logging channel
     * @param targets the logging targets manager
     * @param priority the defauly logging priority
     * @param debug a debug flag
     */
    public DefaultLoggingManager( 
      LogTargetManager targets, CategoriesDirective categories, boolean debug ) 
      throws Exception
    {
        if( null == targets )
        {
            throw new NullPointerException( "targets" );
        }

        m_debug = debug;
        m_targets = targets;

        //
        // setup the default logging priority
        //

        if( !debug )
        {
            getHierarchy().setDefaultPriority( 
              Priority.getPriorityForName( categories.getPriority() ) ); 
        }
        else
        {
            getHierarchy().setDefaultPriority( 
              Priority.getPriorityForName( "DEBUG" ) ); 
        }

        LogTarget target = targets.getLogTarget( "default" );
        getHierarchy().setDefaultLogTarget( target );
        m_logger = setupInternalLogger( categories );
        m_logger.debug( "logging system established" );
        addCategories( categories );
    }

    private Logger setupInternalLogger( CategoriesDirective directive )
    {
        final String root = directive.getName();
        final CategoryDirective category = directive.getCategoryDirective( "logger" );
        final String priority = getLoggingChannelPriority( directive, category );
        final String target = getLoggingChannelTarget( directive, category );
        final String path = root + ".logger";
        return new LogKitLogger( addCategory( path, priority, target ) );
    }

    private String getLoggingChannelPriority( 
      CategoriesDirective directive, CategoryDirective category )
    {
        if( null != category )
        { 
            String priority = category.getPriority();
            if( null != priority ) return priority;
        }
        return directive.getPriority();
    }

    private String getLoggingChannelTarget( 
      CategoriesDirective directive, CategoryDirective category )
    {
        if( null != category )
        { 
            String target = category.getTarget();
            if( null != target ) return target;
        }
        return directive.getTarget();
    }

    private String getDefaultPriority( CategoriesDirective categories )
    {
        if( null != categories )
        { 
            String priority = categories.getPriority();
            if( priority != null ) return priority;
        }
        return DEFAULT_PRIORITY;
    }


    //===============================================================
    // LoggingManager
    //===============================================================

    /**
     * Add a set of category entries using the supplied categories descriptor.
     *
     * @param descriptor a set of category descriptors to be added under the path
     */
    public void addCategories( CategoriesDirective descriptor )
    {
        addCategories( "", descriptor );
    }

    /**
     * Add a set of category entries relative to the supplied base category
     * path, using the supplied descriptor as the definition of subcategories.
     *
     * @param root the category base path
     * @param directive a category directive to add
     */
    public void addCategories( String root, CategoriesDirective directive )
    {
        final String path = filter( root );
        addCategory( path, directive.getPriority(), directive.getTarget() );
        CategoryDirective[] categories = directive.getCategories();
        for( int i = 0; i < categories.length; i++ )
        {
            CategoryDirective category = categories[i];
            final String priority = category.getPriority();
            final String target = category.getTarget();
            final String name = filter( category.getName() );
            if( path.equals( "" ) )
            {
                addCategory( name, priority, target );
            }
            else
            {
                final String base = filter( path + "." + name );
                addCategory( base, priority, target );
            }
        }
    }

    /**
     * Return the Logger for the specified category.
     * @param category the category path
     * @return the logging channel
     */
    public Logger getLoggerForCategory( final String category )
    {
        org.apache.log.Logger log = addCategory( category, null, null );
        return new LogKitLogger( log );
    }

    //===============================================================
    // implementation
    //===============================================================

    private org.apache.log.Logger addCategory( 
      String path, String priority, String target )
    {
        return addCategory( path, priority, target, true );
    }

    private org.apache.log.Logger addCategory( 
      String path, String priority, String target, boolean notify )
    {
        final String name = filter( path );
        final org.apache.log.Logger logger;

        if( null != priority ) 
        {
            if( !name.equals( "" ) )
            {
                debug( "adding category: " + name + ", " + priority.toLowerCase() );
            }
            else
            {
                debug( "adding root category with priority: " + priority.toLowerCase() );
            }
        }
        else
        {
            if( !name.equals( "" ) )
            {
                debug( "adding category: " + name );
            }
            else
            {
                debug( "adding root category" );
            }
        }

        try
        {
            logger = getHierarchy().getLoggerFor( name );
        }
        catch( Throwable e )
        {
            throw new RuntimeException( "Bad category: " + name );
        }

        if( !m_debug && priority != null )
        {
            final Priority priorityValue = Priority.getPriorityForName( priority );
            if( !priorityValue.getName().equals( priority ) )
            {
                final String message = 
                  REZ.getString( "unknown-priority", priority, name );
                throw new IllegalArgumentException( message );
            }
            logger.setPriority( priorityValue );
        }

        if( target != null )
        {
            if( !target.equals( "default" ) )
            {
                final LogTarget logTarget = 
                  (LogTarget) m_targets.getLogTarget( target );
                if( logTarget != null )
                {
                    logger.setLogTargets( new LogTarget[]{ logTarget } );
                }
            }
        }

        return logger;
    }

    private String filter( String name )
    {
        if( name == null ) return "";
        String path = name.replace( '/', '.' );
        if( path.startsWith( "." ) )
        {
            path = path.substring( 1 );
            return filter( path );
        }
        if( path.endsWith( "." ) )
        {
            path = path.substring( 0, path.length() -1 );
            return filter( path );
        }
        return path;
    }

    private Hierarchy getHierarchy()
    {
        return m_hierarchy;
    }

    private void debug( String message )
    {
        if( m_logger != null ) m_logger.debug( message );
    }
}
