/* 
 * Copyright 2004 Apache Software Foundation
 * Licensed  under the  Apache License,  Version 2.0  (the "License");
 * you may not use  this file  except in  compliance with the License.
 * You may obtain a copy of the License at 
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.avalon.logging.logkit;

import java.io.File;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException ;
import java.lang.reflect.Method ;

import org.apache.avalon.framework.logger.Logger;
import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.apache.avalon.framework.configuration.DefaultConfiguration;
import org.apache.avalon.framework.configuration.DefaultConfigurationBuilder;

import org.apache.avalon.logging.provider.LoggingCriteria;
import org.apache.avalon.logging.provider.LoggingException;
import org.apache.avalon.logging.provider.LoggingManager;
import org.apache.avalon.logging.data.CategoriesDirective;
import org.apache.avalon.logging.data.CategoryDirective;

import org.apache.avalon.repository.provider.InitialContext;
import org.apache.avalon.repository.provider.Factory;

import org.apache.avalon.excalibur.i18n.ResourceManager;
import org.apache.avalon.excalibur.i18n.Resources;
import org.apache.excalibur.configuration.ConfigurationUtil;

import org.apache.log.LogTarget;
import org.apache.log.output.io.StreamTarget;
import org.apache.log.format.Formatter;

/**
 * The DefaultLoggingFactory provides support for the establishment of a 
 * new logging system using LogKit as the implementation.
 */
public class DefaultLoggingFactory implements Factory
{
    //--------------------------------------------------------------------------
    // static
    //--------------------------------------------------------------------------

    private static final Resources REZ =
      ResourceManager.getPackageResources( DefaultLoggingFactory.class );

    public static final String DEFAULT_FORMAT =
       "[%7.7{priority}] (%{category}): %{message}\\n%{throwable}";

    public static final Formatter FORMAT = 
       new StandardFormatter( DEFAULT_FORMAT );

    //--------------------------------------------------------------------------
    // immutable state
    //--------------------------------------------------------------------------

    private final ClassLoader m_classloader;
    private final InitialContext m_context;

    //--------------------------------------------------------------------------
    // constructor
    //--------------------------------------------------------------------------

   /**
    * Creation of a new default factory.
    * @param context the repository inital context
    * @param classloader the factory classloader
    */
    public DefaultLoggingFactory( InitialContext context, ClassLoader classloader )
    {
        m_context = context;
        m_classloader = classloader;
    }

    //--------------------------------------------------------------------------
    // Factory
    //--------------------------------------------------------------------------

   /**
    * Return of map containing the default parameters.
    *
    * @return the default parameters 
    */
    public Map createDefaultCriteria()
    {
        return new DefaultLoggingCriteria( m_context );
    }

   /**
    * Creation of a new kernel using the default criteria.
    *
    * @return the kernel instance
    * @exception Exception if an error occurs during root block establishment
    */
    public Object create() throws Exception
    {
        return create( createDefaultCriteria() );
    }

   /**
    * Creation of a new logging manager using the supplied criteria.
    *
    * @param map the parameters 
    * @return the logging manager instance
    * @exception Exception if an error occurs
    */
    public Object create( final Map map ) throws Exception
    {
        if( null == map )
        {
            throw new NullPointerException( "map" );
        }

        final LoggingCriteria criteria = getLoggingCriteria( map );

        //
        // get the logging system configuration
        //

        final Logger logger = criteria.getBootstrapLogger();
        final File basedir = criteria.getBaseDirectory();
        final Configuration config = criteria.getConfiguration();

        //
        // setup the logging target factories
        //

        final Configuration factoriesConfig = config.getChild( "factories" );
        final LogTargetFactoryManager factories = 
          setupTargetFactories( logger, basedir, factoriesConfig );

        //
        // setup the logging targets
        //

        final Configuration targetsConfig = config.getChild( "targets" );
        final Map targetsMap = setupTargets( logger, factories, targetsConfig );
        final LogTargetManager targets = new DefaultLogTargetManager( targetsMap );

        //
        // setup the default log target
        //

        final String name = getRootName( config );
        final String id = getDefaultLoggingTarget( config );
        final String priority = getDefaultLoggingPriority( config );

        setupDefaultLogTarget( targetsMap, id );
        CategoriesDirective categories =
          new CategoriesDirective( 
            name, priority, id, getInternalCategories( logger, config ) );

        //
        // create a logkit logging mananager
        //

        LoggingManager manager = 
          new DefaultLoggingManager( targets, categories, false );

        //
        // setup the default log target
        //

        return manager;
    }

    private LoggingCriteria getLoggingCriteria( Map map )
    {
        if( map instanceof LoggingCriteria )
        {
            return (LoggingCriteria) map;
        }
        else
        {
            final String error = 
              "Unrecognized criteria class: [" 
              + map.getClass().getName();
            throw new IllegalArgumentException( error );
        }
    }

   /**
    * Map the supplied target as the default target. 
    * @param targets the set of establish logging targets
    * @param config the default logging configuration
    */
    private void setupDefaultLogTarget( Map targets, String id )
      throws LoggingException
    {
        if( null == targets.get( id ) )
        {
            if( id.equals( "default" ) )
            {
                LogTarget target = new StreamTarget( 
                  System.out, FORMAT ); 
                targets.put( "default", target );
            }
            else
            {
                final String error = 
                  "Suplied default log target [" + id + "] is unknown.";
                throw new LoggingException( error );
            }
        }
        else
        {
            if( !id.equals( "default" ) )
            {
                targets.put( "default", targets.get( id ) );
            }
        }
    }

    /**
     * Create the log target factories.
     *
     * @param config the factory configuration element.
     * @throws ConfigurationException if the configuration is malformed
     */
    private LogTargetFactoryManager setupTargetFactories( 
      final Logger logger, File basedir, final Configuration config )
      throws LoggingException
    {
        Map factories = new HashMap();
        LogTargetFactoryManager manager = 
          new StandardLogTargetFactoryManager( factories );
        Configuration[] children = config.getChildren();
        for( int i = 0; i < children.length; i++ )
        {
            Configuration child = children[i];
            if( child.getName().equalsIgnoreCase( "factory" ) )
            {
                final String key = getFactoryKey( child );
                try
                {
                    LogTargetFactory factory =
                      createLogTargetFactory( manager, basedir, child );
                    factories.put( key, factory );
                }
                catch( LoggingException e )
                {
                    final String error =
                      "Cannot load log target factory: [" + key + "].";
                    logger.error( error );
                }
            }
            else
            {
                final String error = 
                  "Logging target factories contains an unrecognized element:"
                  + ConfigurationUtil.list( child );
                logger.error( error );
            }
        }
        return manager;
    }

   /**
    * Setup of the log targets declared in the logging configuration.
    * @param logger the logging channel to log establishment events
    * @param manager the log factory manager from which target factories 
    *    are resolved
    * @param config the log targets configuration
    */
    private Map setupTargets( 
      final Logger logger, final LogTargetFactoryManager manager, 
      final Configuration config )
      throws LoggingException
    {
        Map targets = new HashMap();
        Configuration[] children = config.getChildren();
        for( int i = 0; i < children.length; i++ )
        {
            Configuration child = children[i];
            try
            {
                final String id = getTargetId( child );
                final LogTarget target = createLogTarget( manager, child );
                targets.put( id, target );
                final String message = 
                  REZ.getString( "target.notice.add", id );
                logger.debug( message );
            }
            catch( Throwable e )
            {
                final String error = 
                  "Could not load a declared log target.";
                logger.error( error, e );
            }
        }
        return targets;
    }

   /**
    * Create a new log target using a supplied configuration.
    * @param manager the log target factory manager
    * @param config the target configuration
    * @return the logging target
    * @exception Exception if an error occurs during factory creation
    */ 
    private LogTarget createLogTarget( 
      final LogTargetFactoryManager manager, final Configuration config )
      throws LoggingException
    {
         final String key = getTargetFactoryKey( config );
         final LogTargetFactory factory = manager.getLogTargetFactory( key );
         if( factory == null )
         {
            final String message = REZ.getString( "target.error.missing", key );
            throw new LoggingException( message );
         }
         else
         {
            return factory.createTarget( config );
         }
    }

   /**
    * Return the identitying key associated with the log target factory.
    * @param config the log target factory configuration
    * @return the unique key
    */ 
    private String getFactoryKey( Configuration config )
      throws LoggingException
    {
        try
        {
            return config.getAttribute( "type" );
        }
        catch( ConfigurationException e )
        {
            final String error =
              "Missing 'type' attribute on target factory declaration:"
              + ConfigurationUtil.list( config );
            throw new LoggingException( error );
        }
    }

   /**
    * Return the factory key declared by a log target configuration.
    * @param the target configuration
    * @return the factory key
    */
    private String getTargetFactoryKey( Configuration config )
      throws LoggingException
    { 
        return config.getName();
    }

   /**
    * Return the id assigned to a target.
    * @param config the target configuration
    * @return the target id
    * @exception LoggingException if the id is not declared
    */
    private String getTargetId( Configuration config )
      throws LoggingException
    { 
        try
        {
            return config.getAttribute( "id" );
        }
        catch( ConfigurationException e )
        {
            final String error =
              "Missing 'id' attribute on target declaration:"
              + ConfigurationUtil.list( config );
            throw new LoggingException( error );
        }
    }

   /**
    * Return the class attribute from a factory element.
    * @param config the target factory configuration
    * @return the target classname
    * @exception LoggingException if the class attribute is not declared
    */
    private String getFactoryClassname( Configuration config )
      throws LoggingException
    { 
        try
        {
            return config.getAttribute( "class" );
        }
        catch( ConfigurationException e )
        {
            final String error =
              "Missing 'class' attribute on factory declaration:"
              + ConfigurationUtil.list( config );
            throw new LoggingException( error );
        }
    }

    public final class StandardLogTargetFactoryManager 
       implements LogTargetFactoryManager
    {
        private Map m_map;

       /**
        * Creation of a new log target factory manager.
        * @param map the initially empty set of log target factories
        */
        public StandardLogTargetFactoryManager( Map map )
        {
            m_map = map;
        }

       /**
        * Retrieves a LogTargetFactory from a name. If
        * this LogTargetFactoryManager does not have the match a null
        * will be returned.
        *
        * @param key name of a LogTargetFactory.
        * @return the LogTargetFactory or null if not found.
        */
        public LogTargetFactory getLogTargetFactory( String key )
        {
             return (LogTargetFactory) m_map.get( key );
        }
    }

   /**
    * Load a factory class using a supplied factory classname.
    * @param factory the factory classname
    * @return the factory class
    * @exception LoggingException if a factory class loading error occurs
    */
    protected Class loadFactoryClass( String classname )
        throws LoggingException
    {
        try
        {
            return m_classloader.loadClass( classname );
        }
        catch( ClassNotFoundException e )
        {
            final String error = 
              "Could not find the log target factory class: " + classname;
            throw new LoggingException( error, e );
        }
        catch( Throwable e )
        {
            final String error = 
              "Unable to load the log target factory class: [" 
              + classname 
              + "].";
            throw new LoggingException( error, e );
        }
    }

   /**
    * <p>Create a new logging target factory instance.  A logging target must 
    * implement one of the following constructor patterns:</p>
    * <ul>
    * <li>[InitialContext, ClassLoader, LogTargetFactoryManager, File]</li>
    * <li>[ClassLoader, LogTargetFactoryManager, File]</li>
    * <li>[LogTargetFactoryManager, File]</li>
    * <li>[LogTargetFactoryManager]</li>
    * <li>[File]</li>
    * <li>[]</li>
    * </ul>
    */
    private LogTargetFactory createLogTargetFactory( 
      LogTargetFactoryManager manager, File basedir, 
      Configuration config ) 
      throws LoggingException
    {
        String classname = getFactoryClassname( config );

        Class clazz = loadFactoryClass( classname );

        try
        {
            Constructor constructor = 
              clazz.getConstructor( 
                new Class[]{ 
                  InitialContext.class, 
                  ClassLoader.class,
                  LogTargetFactoryManager.class,
                  File.class } );
            return createLogTargetFactory( 
              constructor, new Object[]{ 
                m_context, m_classloader, manager, basedir } );
        }
        catch( NoSuchMethodException e )
        {
            try
            {
                Constructor constructor = 
                  clazz.getConstructor( 
                    new Class[]{ 
                      ClassLoader.class,
                      LogTargetFactoryManager.class,
                      File.class } );
                return createLogTargetFactory( 
                  constructor, new Object[]{ 
                    m_classloader, manager, basedir } );
            }
            catch( NoSuchMethodException ee )
            {
                try
                {
                    Constructor constructor = 
                      clazz.getConstructor( 
                        new Class[]{ 
                          LogTargetFactoryManager.class,
                          File.class } );
                    return createLogTargetFactory( 
                      constructor, new Object[]{ 
                        manager, basedir } );
                }
                catch( NoSuchMethodException eee )
                {
                    try
                    {
                        Constructor constructor = 
                          clazz.getConstructor( 
                            new Class[]{ 
                              LogTargetFactoryManager.class } );
                        return createLogTargetFactory( 
                          constructor, new Object[]{ manager } );
                    }
                    catch( NoSuchMethodException eeee )
                    {
                        try
                        {
                            Constructor constructor = 
                              clazz.getConstructor( 
                                new Class[]{ 
                                  File.class } );
                            return createLogTargetFactory( 
                              constructor, new Object[]{ basedir } );
                        }
                        catch( NoSuchMethodException eeeee )
                        {
                            try
                            {
                                Constructor constructor = 
                                  clazz.getConstructor( 
                                    new Class[0] );
                                return createLogTargetFactory( 
                                  constructor, new Object[0] );
                            }
                            catch( NoSuchMethodException eeeeee )
                            {
                                StringBuffer buffer = new StringBuffer();
                                buffer.append( "Supplied log factory class [" );
                                buffer.append( clazz.getName() );
                                buffer.append( 
                                  " ] does not implement a recognized constructor." );
                                throw new LoggingException( buffer.toString() );
                            }
                        }
                    }
                }
            }
        }
    }

   /**
    * Instantiation of a factory instance using a supplied constructor 
    * and arguments.
    * 
    * @param constructor the factory constructor
    * @param args the constructor arguments
    * @return the factory instance
    * @exception LoggingException if an instantiation error occurs
    */
    private LogTargetFactory createLogTargetFactory( 
      Constructor constructor, Object[] args ) 
      throws LoggingException
    {
        Class clazz = constructor.getDeclaringClass();
        try
        {
            return (LogTargetFactory) constructor.newInstance( args );
        }
        catch( Throwable e )
        {
            final String error = 
              "Error while attempting to instantiate the factory: [" 
              + clazz.getName() 
              + "]."; 
            throw new LoggingException( error, e );
        }
    }

    private String getDefaultLoggingPriority( Configuration config )
    {
        // handle the 3.0-2 legacy style
        final String priority = config.getAttribute( "priority", null );
        if( null != priority ) return priority;

        // handle 3.3 full <categories> element
        return config.getChild( "categories" ).getAttribute( "priority", null ); 
    }

    private String getDefaultLoggingTarget( Configuration config )
    {
        // handle the 3.0-2 legacy style
        final String target = config.getAttribute( "target", null );
        if( null != target ) return target;

        // handle 3.3 full <categories> element
        return config.getChild( "categories" ).getAttribute( "target", "default" ); 
    }

    private String getRootName( Configuration config )
    {
        // handle the 3.0-2 legacy style
        final String name = config.getAttribute( "name", null );
        if( null != name ) return name;

        // handle 3.3 full <categories> name
        return config.getChild( "categories" ).getAttribute( "name", "root" ); 
    }

    private CategoryDirective[] getInternalCategories( 
      Logger logger, Configuration config )
    {
        // handle the 3.0-2 legacy style
        Configuration[] categories = config.getChildren( "category" );
        if( categories.length > 0 ) 
        {
            return createCategories( logger, categories );
        }

        // handle 3.3 full <categories> element
        return createCategories( 
          logger, 
          config.getChild( "categories" ).getChildren( "category" ) );
    }

    private CategoryDirective[] createCategories( 
      Logger logger, Configuration[] configs )
    {
        ArrayList list = new ArrayList();
        for( int i=0; i<configs.length; i++ )
        {
            Configuration config = configs[i];
            try
            {
                CategoryDirective category = createCategory( config );
                list.add( category );
            }
            catch( LoggingException e )
            {
                final String error = 
                  "Ignoring invalid category directive:"
                  + ConfigurationUtil.list( config );
                logger.error( error, e );
            }
        }
        return (CategoryDirective[]) list.toArray( new CategoryDirective[0] );
    }

    private CategoryDirective createCategory( Configuration config ) 
      throws LoggingException
    {
        final String name = config.getAttribute( "name", null );
        if( null == name )
        {
            final String error = 
              "Missing category 'name' attribute.";
            throw new LoggingException( error );
        }
        final String priority = config.getAttribute( "priority", null );
        final String target = config.getAttribute( "targets", null );
        return new CategoryDirective( name, priority, target );
    }

    
}